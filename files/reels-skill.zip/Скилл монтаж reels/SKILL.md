---
name: "reels-montage"
description: "Монтаж разговорных reels в стиле Софьи Мэд (шрифт Montserrat): ffmpeg + Remotion, резка пауз и дублей, ×1.3, чистка цоканья, 5 хуков на выбор, субтитры по одному слову, тезисы и карточки по смыслу, цензура. Используй, когда просят смонтировать ролик или reels."
---

# Монтажёр reels — шаблон Софьи Мэд

Ты — монтажёр вертикальных разговорных reels 1080×1920: человек крупно говорит в камеру, графика сверху (над головой) и снизу (на груди), лицо НИКОГДА не закрыто. Шаблон фиксированный: меняются исходник и тексты, дизайн не переизобретать.

Весь код шаблона — ниже в этом файле (раздел 5). Ничего не придумывай заново: разложи файлы и пользуйся ими.

## 0. Первый запуск (один раз)

1. **Рабочая папка.** Спроси пользователя, где её создать; если ему всё равно — `reels/` на Рабочем столе (`~/Desktop/reels`). Создай в ней `input/`, `output/`, `done/`, `fonts/`, `assets/`, `kit/`. Новые видео пользователь кладёт в `input/` или просто в корень папки — бери любые .MOV/.MP4 из корня тоже. Путь к папке может содержать пробелы и кириллицу — всегда бери пути в кавычки.
2. Разложи файлы из раздела 5 в `kit/` ровно по указанным путям (если у пользователя есть папка скилла с готовым `kit/` — можно просто скопировать её).
3. Поставь недостающее сам (определи ОС):
   - `ffmpeg` (на Mac — `brew install ffmpeg`: в этой сборке есть фильтр `zscale`, нужный для HDR-видео с iPhone);
   - Python 3 с `numpy`, `scipy`, `pillow`: `python3 -m pip install numpy scipy pillow`. Если pip отвечает `externally-managed-environment` — `python3 -m pip install --user --break-system-packages numpy scipy pillow`;
   - Node.js ≥ 18; в `kit/remotion/` и `kit/scripts/` выполни `npm i`;
   - **Шрифты и градиент**: `python3 kit/scripts/setup_assets.py "РАБОЧАЯ_ПАПКА"`. Скрипт сам найдёт `Montserrat-ExtraBold.ttf`, `Montserrat-Medium.ttf`, `gradient-niz.png`, если пользователь положил их в рабочую папку (в любую подпапку); иначе скачает Montserrat через npm (бесплатный шрифт, лицензия OFL) и нарисует градиент сам. У пользователя ничего просить не нужно;
   - На Windows скрипт `qa.sh` запускай через Git Bash или WSL.
   - Модель распознавания (Whisper small, ONNX, ~240 МБ) скачается сама при первом запуске `transcribe.mjs`. Если Hugging Face недоступен (`ENOTFOUND huggingface.co`) — в `kit/scripts/` выполни `npm pack sts-whisper-small && tar xzf sts-whisper-small-*.tgz` (появится папка `package/` с моделью, скрипт найдёт её сам).
   - Если Remotion не может скачать свой Chrome (`ENOTFOUND storage.googleapis.com` или зависает на «Downloading Chrome Headless Shell») — пропиши установленный Chrome/Chromium в `kit/remotion/remotion.config.ts` (`Config.setBrowserExecutable`, примеры путей там в комментарии).
4. Одной строкой сообщи: Remotion бесплатен для частных лиц и команд до 3 человек, компаниям крупнее нужна лицензия (remotion.dev/license).

## 1. Константы стиля (не менять без просьбы)

- Кадр 1080×1920, 30 fps, H.264. Видео другого формата не растягивается, а заполняет кадр с обрезкой краёв. HDR с iPhone автоматически переводится в SDR. Скорость ×1.3 (тон не меняется). Голос −14 LUFS (точная подгонка + мягкий лимитер пиков −1.5 дБ). Лёгкий цветокор. Музыки и звуков НЕТ.
- Цвета: белый `#FFFFFF`, ярко-розовый `#FF2A94`, тёмные карточки `#151515`, светлые `#F7F6F4`. Шрифты: КАПС — Montserrat ExtraBold, тонкий текст — Montserrat Medium.
- Градиент `gradient-niz.png` снизу на весь ролик, под текстами.
- **Лицо**: вся верхняя графика заканчивается выше макушки (≈ y 545 при обычной посадке), нижняя — ниже подбородка. Если элемент сверху не помещается (высокая карточка) — ставь его вниз (`"pos": "bottom"`), субтитры на это время скрываются автоматически.
- **Хук** (0 → ~3 с): белые строки КАПСОМ + акцент розовым КАПСОМ крупно; длинный акцент — в 2 строки через `\n`, длинные белые — тоже в 2 строки.
- **Тезис**: маленькая белая подпись строчными + розовый КАПС.
- **Панчлайн**: белый КАПС на груди + розовая линия-подчёркивание; 0–2 на ролик.
- **Список с точками**, **карточки**: `cardList` (01/02/03), `cardQuote` (фраза печатается синхронно с речью), `cardBeforeAfter` (было/стало, подсветки с бейджами, перенос строки `{"br": true}`), `cardIcons` (силуэты «клиент / вы», акцент-точка), `cardProgress` (шкала). Одновременно — максимум один верхний элемент.
- **Субтитры**: по ОДНОМУ слову, внизу на градиенте (y≈1640), Montserrat Medium 60 px белым. Ключевые слова — жирные белые (Montserrat ExtraBold). Розовым субтитры НЕ делать, если человек в розовой/красной одежде — они пропадают.
- **Зумы** по смыслу: 1.00–1.08, плавно, 3–6 на 30 с.
- **Цензура** во всех текстах на экране: д*ньги, бюдж*т, ст*имость, р*блей и т. п. (словарь `CENSOR` в `common.py`) + слова из ТЗ «ЦЕНЗУРА:» (добавь в `props.py`: `CENSOR['слово'] = 'сл*во'`). `save()` применяет цензуру сам ко всем текстам — субтитрам, хуку, тезисам, карточкам, бейджам — с сохранением заглавных букв.

## 2. Пайплайн

WD = рабочая папка ролика, `kit/work/<имя>/`. **Во всех командах используй абсолютные пути в кавычках** (рендер запускается из `kit/remotion/`, относительный путь к props оттуда не найдётся).

1. **Распознавание**: `python3 kit/scripts/islands.py ВИДЕО WD` → `node kit/scripts/transcribe.mjs WD`. Каждый дубль (кусок речи между паузами) распознаётся отдельно — так видны все дубли и оговорки. Первый запуск может занять пару минут (загрузка модели).
   - Большое видео с компьютера пользователя (> ~300 МБ) не тянется целиком — режь на месте без перекодирования: `ffmpeg -i IN -map 0:v:0 -map 0:a:0 -c copy -f segment -segment_time 70 -reset_timestamps 0 parts/p%02d.mov`, забирай части и склей concat-демуксером (`-c copy`).
2. **Выбор дублей**: из каждой фразы бери ПОСЛЕДНИЙ полный и чистый дубль. Выбрасывай оговорки, «ну ладно», «да, вот так», обрывки. Галлюцинации распознавания на тишине («Субтитры…», «С вами был …», «Спасибо», «Смешно», одиночные короткие слова на куске < 0.5 с) не бери в дубли.
3. **5 хуков** ← ОСТАНОВКА. Предложи 5 вариантов «белые строки / РОЗОВЫЙ АКЦЕНТ», разные по механике (результат-цифра, запрет «перестаньте…», ошибка, контраст, интрига). Пользователь выбирает номер или пишет свой. Если хук дан в ТЗ (`ХУК:`) — без вариантов. Пока ждёшь — делай шаг 4.
4. **Основа**: `python3 kit/scripts/make_base.py ВИДЕО WD "a-b,a-b,..."` (секунды дублей в исходнике, с запасом ~0.2 с). Скрипт режет дубли, убирает паузы > 0.35 с внутри, продлевает конец каждого дубля до полной тишины (чтобы не срезать тихие «-к», «-т»), переводит HDR в SDR, ускоряет, выводит громкость на −14 LUFS → `WD/base.mp4` и `WD/words_out.json` (слова на шкале ролика). Если скрипт пишет `WARNING: HDR source` — поставь ffmpeg с zimg и перезапусти.
5. **Чистка цоканья**: `ffmpeg -i WD/base.mp4 -vn -c:a pcm_s16le -ar 48000 WD/a.wav` → `python3 kit/scripts/declick.py WD/a.wav WD/a_clean.wav` → `ffmpeg -i WD/base.mp4 -i WD/a_clean.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k WD/base_clean.mp4`. Убираются только высокочастотные щелчки длиной в несколько мс; голос и окончания не трогаются. Положи результат в `kit/remotion/public/<имя>.mp4`.
6. **Тексты и графика** — напиши `WD/props.py` на основе `common.py` (пример в разделе 5). Исправь ошибки распознавания через `replace_seq` (окончания, «платёжеспособный» слитно, «Я могу» и т. п.; токены пиши без знаков препинания). Графику расставляй сам по смыслу, каждую — на конкретную фразу. Ориентир на 30–50 с: хук + 3–5 тезисов + 1–3 карточки/списка + 0–2 панчлайна + финальный тезис-призыв.
7. **Контрольные кадры** ← ОСТАНОВКА. `kit/scripts/qa.sh WD/props.json WD/qa кадр1 кадр2 …` (номера кадров при 30 fps: хук, каждый тезис, каждая карточка в момент, когда видны все пункты, панчлайн). Если кадр не отрисовался — скрипт остановится и покажет ошибку Remotion. Посмотри лист сам: лицо свободно, ничего не обрезано, бейджи не наезжают на текст. Пришли пользователю лист кадров + ПОЛНЫЙ текст субтитров на вычитку (ошибки распознавания — самая частая правка). Правки → снова кадры.
8. **Рендер**: в `kit/remotion/`: `npx remotion render src/index.ts Reel "АБС_ПУТЬ/render.mp4" --props="АБС_ПУТЬ/WD/props.json" --codec=h264 --crf=18 --concurrency=2`. Затем сжать для отправки: `ffmpeg -i render.mp4 -c:v libx264 -crf 21 -preset slow -c:a copy -movflags +faststart output/<тема>-final.mp4` (≈ 20–30 МБ на 30–50 с живого видео).
9. **Финал**: ролик → `output/<тема латиницей>-final.mp4`; исходник → `done/` (не удалять никогда; дубликат того, что уже в `done/`, — в `_to_delete/`). Если результат пишется на компьютер пользователя через загрузку — после записи сверь контрольную сумму (md5) файла на компьютере с локальным, иначе там может остаться старая версия. Отчёт: длительность, выбранный хук, список графики с таймкодами.

## 3. Словарь ТЗ

| Пишут | Делаешь |
|---|---|
| ХУК: строки / АКЦЕНТ | этот хук без вариантов |
| ТЕЗИС на «фраза»: текст | тезис на этой фразе |
| КАРТОЧКА на «фраза»: … | карточка подходящего типа |
| ПАНЧ: текст | панчлайн |
| ЦЕНЗУРА: слова | `CENSOR['слово'] = 'сл*во'` в props.py — звёздочки во всех текстах |
| без зумов / без карточек | не делать |

## 4. Правила

- Останавливаться только на хуке и контрольных кадрах; остальное решать самому и отмечать в отчёте.
- Не экспортировать, если: графика на лице; субтитры не по одному слову или не синхронны; текст обрезан или выходит за поля 90 px; два верхних элемента одновременно; срезано окончание слова в конце дубля; цензура пропущена.
- Исходники не удалять. `fonts/`, `assets/`, `kit/` не трогать (кроме `kit/work/` и `kit/remotion/public/*.mp4`, которые можно чистить после финала, и `remotion.config.ts`, если нужно прописать браузер).

## 5. Файлы шаблона (разложить в `kit/`)

### `kit/remotion/package.json`

```json
{
  "name": "reels-template",
  "private": true,
  "dependencies": {
    "@remotion/cli": "4.0.300",
    "remotion": "4.0.300",
    "react": "18.3.1",
    "react-dom": "18.3.1"
  }
}
```

### `kit/remotion/tsconfig.json`

```json
{"compilerOptions":{"target":"ES2018","module":"commonjs","jsx":"react-jsx","strict":false,"esModuleInterop":true,"skipLibCheck":true,"lib":["dom","es2018"]}}
```

### `kit/remotion/remotion.config.ts`

```ts
import {Config} from '@remotion/cli/config';
// If Remotion cannot download its own headless Chrome, point it to an installed Chrome/Chromium, e.g.:
//   macOS:   Config.setBrowserExecutable('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
//   Windows: Config.setBrowserExecutable('C:/Program Files/Google/Chrome/Application/chrome.exe');
//   Linux:   Config.setBrowserExecutable('/usr/bin/chromium');
Config.setVideoImageFormat('jpeg');
```

### `kit/remotion/src/index.ts`

```ts
import {registerRoot} from 'remotion';
import {RemotionRoot} from './Root';
registerRoot(RemotionRoot);
```

### `kit/remotion/src/Root.tsx`

```tsx
import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Reel"
    component={Reel as any}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={300}
    defaultProps={{duration: 10, words: [], overlays: [], zooms: [], face: {cx: 540, cy: 820}} as any}
    calculateMetadata={({props}: any) => ({durationInFrames: Math.round((props.duration || 10) * 30)})}
  />
);
```

### `kit/remotion/src/Reel.tsx`

```tsx
import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Img, OffthreadVideo, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender} from 'remotion';

const PINK = '#FF2A94';
const WHITE = '#FFFFFF';
const DARK = '#151515';
const LIGHT = '#F7F6F4';
const XB = 'MontserratXB';
const BK = 'MontserratMedium';
const SHADOW = '0 4px 18px rgba(0,0,0,.25)';

const clamp = (x: number) => Math.max(0, Math.min(1, x));
const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
const smooth = (x: number) => {const c = clamp(x); return c * c * (3 - 2 * c);};

// opacity / progress for an element living in [t, end]
const life = (now: number, t: number, end: number, inDur = 0.2, outDur = 0.2) => {
  if (now < t || now > end + outDur) return {o: 0, p: 0};
  const p = easeOut((now - t) / inDur);
  const out = now > end ? 1 - clamp((now - end) / outDur) : 1;
  return {o: Math.min(p, out), p};
};

const FontLoader: React.FC = () => {
  const [handle] = useState(() => delayRender('fonts'));
  useEffect(() => {
    const a = new FontFace(XB, `url(${staticFile('fonts/Montserrat-ExtraBold.ttf')})`);
    const b = new FontFace(BK, `url(${staticFile('fonts/Montserrat-Medium.ttf')})`);
    Promise.all([a.load(), b.load()]).then((fs) => {
      fs.forEach((f) => (document.fonts as any).add(f));
      continueRender(handle);
    });
  }, [handle]);
  return null;
};

type Word = {t: number; end: number; text: string; pink?: boolean};

// ---------- HOOK ----------
const Hook: React.FC<{now: number; h: any}> = ({now, h}) => {
  const out = now > h.end ? 1 - clamp((now - h.end) / 0.15) : 1;
  if (out <= 0) return null;
  return (
    <div style={{position: 'absolute', top: h.top, left: 0, width: 1080, textAlign: 'center', opacity: out, textShadow: SHADOW}}>
      {h.lines.map((l: string, i: number) => (
        <div key={i} style={{fontFamily: XB, fontSize: h.lineSize, lineHeight: 0.95, color: WHITE, letterSpacing: 0.5}}>{l}</div>
      ))}
      {String(h.accent).split('\n').map((a: string, i: number) => <div key={'a' + i} style={{fontFamily: XB, fontSize: h.accentSize, lineHeight: 0.98, color: PINK, marginTop: i ? 0 : 6}}>{a}</div>)}
    </div>
  );
};

// ---------- THESIS ----------
const Thesis: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op, p} = life(now, o.t, o.end);
  if (op <= 0) return null;
  return (
    <div style={{position: 'absolute', top: o.top ?? 330, left: 0, width: 1080, textAlign: 'center', opacity: op, transform: `translateY(${(1 - p) * 16}px)`, textShadow: SHADOW}}>
      <div style={{fontFamily: BK, fontSize: 30, color: WHITE, marginBottom: 6}}>{o.label}</div>
      <div style={{fontFamily: XB, fontSize: o.size ?? 72, lineHeight: 1, color: PINK}}>{o.title}</div>
    </div>
  );
};

// ---------- PUNCH ----------
const Punch: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op, p} = life(now, o.t, o.end, 0.18);
  if (op <= 0) return null;
  const line = smooth((now - o.t - 0.12) / 0.25);
  return (
    <div style={{position: 'absolute', top: o.top ?? 1400, left: 0, width: 1080, display: 'flex', justifyContent: 'center', opacity: op, transform: `scale(${0.96 + 0.04 * p})`}}>
      <div style={{display: 'inline-block'}}>
        <div style={{fontFamily: XB, fontSize: o.size ?? 90, lineHeight: 1, color: WHITE, textShadow: SHADOW, whiteSpace: 'nowrap'}}>{o.text}</div>
        <div style={{height: 11, background: PINK, borderRadius: 6, marginTop: 15, width: `${line * 100}%`}} />
      </div>
    </div>
  );
};

// ---------- DOTS ----------
const Dots: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op} = life(now, o.t, o.end);
  if (op <= 0) return null;
  return (
    <div style={{position: 'absolute', top: o.top ?? 330, left: 0, width: 1080, textAlign: 'center', opacity: op, textShadow: SHADOW}}>
      {o.items.map((it: any, i: number) => {
        const q = easeOut((now - it.t) / 0.2);
        return (
          <div key={i} style={{fontFamily: BK, fontSize: 44, lineHeight: 1.6, color: WHITE, opacity: q, transform: `translateY(${(1 - q) * 10}px)`}}>
            <span style={{display: 'inline-block', width: 10, height: 10, borderRadius: 5, background: PINK, marginRight: 16, verticalAlign: 'middle'}} />
            {it.text}
          </div>
        );
      })}
    </div>
  );
};

// ---------- CARDS ----------
const CardShell: React.FC<{now: number; o: any; dark?: boolean; children: React.ReactNode}> = ({now, o, dark, children}) => {
  const {o: op, p} = life(now, o.t, o.end, 0.28, 0.2);
  if (op <= 0) return null;
  const w = o.width ?? 820;
  return (
    <div style={{position: 'absolute', ...(o.pos === 'bottom' ? {bottom: o.bottom ?? 170} : {top: o.top ?? 140}), left: (1080 - w) / 2, width: w, boxSizing: 'border-box', padding: 36, borderRadius: 24,
      background: dark ? DARK : LIGHT, color: dark ? WHITE : '#111', boxShadow: '0 10px 40px rgba(0,0,0,.25)',
      opacity: op, transform: `translateY(${(1 - p) * 24}px) scale(${0.97 + 0.03 * p})`}}>
      {children}
    </div>
  );
};

const Tag: React.FC<{text: string}> = ({text}) => (
  <div style={{background: PINK, color: WHITE, fontFamily: XB, fontSize: 24, padding: '8px 18px', borderRadius: 30, letterSpacing: 0.5, whiteSpace: 'nowrap'}}>{text}</div>
);

const CardHeader: React.FC<{title: string; tag?: string}> = ({title, tag}) => (
  <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22}}>
    <div style={{fontFamily: XB, fontSize: 42}}>{title}</div>
    {tag ? <Tag text={tag} /> : null}
  </div>
);

const reveal = (now: number, t: number) => easeOut((now - t) / 0.18);

const CardList: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={o}>
    <CardHeader title={o.title} tag={o.tag} />
    {o.items.map((it: any, i: number) => (
      <div key={i} style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 14, opacity: reveal(now, it.t)}}>
        <div style={{border: `2px solid ${PINK}`, color: PINK, borderRadius: 8, fontFamily: XB, fontSize: 20, padding: '4px 8px'}}>{String(i + 1).padStart(2, '0')}</div>
        <div style={{fontFamily: BK, fontSize: 38}}>{it.text}</div>
      </div>
    ))}
  </CardShell>
);

const CardQuote: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={o}>
    <CardHeader title={o.title} tag={o.tag} />
    <div style={{display: 'flex', gap: 22}}>
      <div style={{width: 6, borderRadius: 3, background: PINK, minHeight: o.minHeight ?? 150}} />
      <div style={{fontFamily: BK, fontSize: 40, lineHeight: 1.4}}>
        {o.words.map((w: any, i: number) => (
          <span key={i} style={{opacity: now >= w.t ? 1 : 0, color: w.pink ? PINK : undefined}}>{w.text} </span>
        ))}
      </div>
    </div>
  </CardShell>
);

const CardBeforeAfter: React.FC<{now: number; o: any}> = ({now, o}) => {
  const q = reveal(now, o.afterT);
  return (
    <CardShell now={now} o={o}>
      <CardHeader title={o.title} tag={o.tag} />
      <div style={{fontFamily: BK, fontSize: 26, color: '#8a8a8a'}}>было:</div>
      <div style={{fontFamily: BK, fontSize: 38, color: '#8a8a8a', textDecoration: 'line-through', textDecorationColor: PINK, marginTop: 4}}>{o.before}</div>
      <div style={{opacity: q, marginTop: 20}}>
        <div style={{fontFamily: BK, fontSize: 26, color: '#8a8a8a'}}>стало:</div>
        <div style={{fontFamily: BK, fontSize: 38, lineHeight: 2.2, marginTop: 10}}>
          {o.after.map((s: any, i: number) => s.hl ? (
            <span key={i} style={{position: 'relative', background: 'rgba(255,42,148,.25)', borderRadius: 6, padding: '0 4px'}}>
              {s.badge ? <span style={{position: 'absolute', top: -31, left: 0, background: PINK, color: WHITE, fontFamily: XB, fontSize: 15, padding: '2px 8px', lineHeight: 1.3, borderRadius: 20, whiteSpace: 'nowrap'}}>{s.badge}</span> : null}
              {s.text}
            </span>
          ) : s.br ? <br key={i} /> : <span key={i}>{s.text}</span>)}
        </div>
      </div>
    </CardShell>
  );
};

const Person: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={WHITE} strokeWidth={2.2}>
    <circle cx="50" cy="34" r="18" />
    <path d="M14 92c4-20 18-30 36-30s32 10 36 30" />
  </svg>
);

const CardIcons: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={{...o, width: o.width ?? 640}} dark>
    <div style={{display: 'flex', justifyContent: 'space-around', alignItems: 'flex-end', paddingTop: 30}}>
      {o.people.map((pp: any, i: number) => {
        const q = reveal(now, pp.t ?? o.t);
        const acc = pp.accent ? reveal(now, pp.accent.t) : 0;
        return (
          <div key={i} style={{textAlign: 'center', opacity: q, position: 'relative'}}>
            {pp.accent ? (
              <div style={{position: 'absolute', top: -34, left: 0, right: 0, opacity: acc, fontFamily: XB, fontSize: 22, color: WHITE, whiteSpace: 'nowrap'}}>{pp.accent.text}</div>
            ) : null}
            <div style={{position: 'relative'}}>
              <Person size={150} />
              {pp.accent ? <div style={{position: 'absolute', top: 30, left: 88, width: 26, height: 26, borderRadius: 13, background: PINK, opacity: acc, boxShadow: `0 0 18px ${PINK}`}} /> : null}
            </div>
            <div style={{fontFamily: BK, fontSize: 34, marginTop: 10}}>{pp.label}</div>
          </div>
        );
      })}
    </div>
  </CardShell>
);

const CardProgress: React.FC<{now: number; o: any}> = ({now, o}) => {
  const fill = smooth((now - o.t - 0.2) / 0.8) * o.percent;
  return (
    <CardShell now={now} o={{...o, width: o.width ?? 640}} dark>
      <div style={{fontFamily: XB, fontSize: 26, textAlign: 'center'}}>{o.title}</div>
      <div style={{height: 14, background: '#333', borderRadius: 7, marginTop: 22, overflow: 'hidden'}}>
        <div style={{height: '100%', width: `${fill}%`, background: PINK, borderRadius: 7}} />
      </div>
      <div style={{textAlign: 'right', fontFamily: BK, fontSize: 18, marginTop: 6}}>{Math.round(fill)}%</div>
      {(o.items || []).map((it: any, i: number) => (
        <div key={i} style={{fontFamily: BK, fontSize: 26, marginTop: 14, opacity: reveal(now, it.t)}}>▫ {it.text}</div>
      ))}
    </CardShell>
  );
};

// ---------- SUBTITLES ----------
const Subs: React.FC<{now: number; words: Word[]}> = ({now, words}) => {
  let cur: Word | null = null;
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const next = words[i + 1];
    const until = Math.min(next ? next.t : Infinity, w.end + 0.6);
    if (now >= w.t && now < until) {cur = w; break;}
  }
  if (!cur) return null;
  const q = easeOut((now - cur.t) / 0.08);
  return (
    <div style={{position: 'absolute', top: 1640 - 40, left: 0, width: 1080, height: 80, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{fontFamily: cur.pink ? XB : BK, fontSize: cur.pink ? 64 : 60, color: WHITE, opacity: q, transform: `scale(${0.92 + 0.08 * q})`, textShadow: '0 2px 14px rgba(0,0,0,.45)'}}>{cur.text}</div>
    </div>
  );
};

// ---------- ZOOM ----------
const zoomAt = (now: number, zooms: {t: number; scale: number}[]) => {
  let s = 1;
  for (const z of zooms) {
    if (now < z.t) break;
    const k = smooth((now - z.t) / 0.45);
    s = s + (z.scale - s) * k;
  }
  return s;
};

export const Reel: React.FC<any> = (props) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const now = frame / fps;
  const zs = zoomAt(now, props.zooms || []);
  const face = props.face || {cx: 540, cy: 820};
  const C: Record<string, React.FC<{now: number; o: any}>> = {
    thesis: Thesis, punch: Punch, dots: Dots, cardList: CardList, cardQuote: CardQuote,
    cardBeforeAfter: CardBeforeAfter, cardIcons: CardIcons, cardProgress: CardProgress,
  };
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <FontLoader />
      <AbsoluteFill style={{transform: `scale(${zs})`, transformOrigin: `${face.cx}px ${face.cy}px`}}>
        <OffthreadVideo src={staticFile(props.video || 'base.mp4')} />
      </AbsoluteFill>
      <Img src={staticFile('gradient-niz.png')} style={{position: 'absolute', bottom: 0, left: 0, width: 1080}} />
      {(props.overlays || []).filter((o: any) => o.type !== 'punch').map((o: any, i: number) => {
        const Comp = C[o.type];
        return Comp ? <Comp key={i} now={now} o={o} /> : null;
      })}
      {(props.overlays || []).filter((o: any) => o.type === 'punch').map((o: any, i: number) => <Punch key={'p' + i} now={now} o={o} />)}
      {props.hook ? <Hook now={now} h={props.hook} /> : null}
      {(props.overlays || []).some((o: any) => o.pos === 'bottom' && now >= o.t - 0.05 && now <= o.end + 0.2) ? null : <Subs now={now} words={props.words || []} />}
    </AbsoluteFill>
  );
};
```

### `kit/scripts/package.json`

```json
{ "name": "reels-scripts", "private": true, "type": "module",
  "dependencies": { "@huggingface/transformers": "3.8.1", "wavefile": "11.0.0" } }
```

### `kit/scripts/islands.py`

```python
"""islands.py SRC WORKDIR -> WORKDIR/audio.wav (16 kHz mono) + islands.json (speech chunks, one per take)."""
import sys, os, json, subprocess, numpy as np, wave
src, wd = sys.argv[1], sys.argv[2]
os.makedirs(wd, exist_ok=True)
wav = os.path.join(wd, 'audio.wav')
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', src, '-vn', '-ac', '1', '-ar', '16000', wav], check=True)
w = wave.open(wav); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
win = 1600  # 0.1 s
db = 20 * np.log10(np.sqrt(np.mean(a[:len(a) // win * win].reshape(-1, win) ** 2, axis=1)) + 1e-9)
# threshold: between noise floor and speech level (quiet gated mics sit near -80 dB)
thr = max(-62, min(-40, (np.percentile(db, 20) + np.percentile(db, 90)) / 2))
sp = db > thr; segs = []; s = None
for i, v in enumerate(sp):
    if v and s is None: s = i
    if not v and s is not None: segs.append([s, i]); s = None
if s is not None: segs.append([s, len(sp)])
m = []
for x in segs:
    if m and x[0] - m[-1][1] <= 3: m[-1][1] = x[1]
    else: m.append(x)
m = [(a_ / 10, b_ / 10) for a_, b_ in m if b_ - a_ >= 2]
json.dump(m, open(os.path.join(wd, 'islands.json'), 'w'))
print('threshold', round(thr), 'dB; islands:', len(m))
```

### `kit/scripts/transcribe.mjs`

```js
// node transcribe.mjs WORKDIR  -> WORKDIR/isl_words.json (every take transcribed separately, word timings)
// Model: Xenova/whisper-small via transformers.js. Downloads from Hugging Face; if that is blocked,
// install the npm mirror once:  npm pack sts-whisper-small && tar xzf sts-whisper-small-*.tgz  (in this scripts folder)
import { pipeline, env } from '@huggingface/transformers';
import fs from 'fs'; import path from 'path'; import wf from 'wavefile'; import { fileURLToPath } from 'url';
const wd = process.argv[2];
const here = path.dirname(fileURLToPath(import.meta.url));  // works with spaces/Cyrillic in the path and on Windows
const local = path.join(here, 'package', 'models');
if (fs.existsSync(path.join(local, 'Xenova', 'whisper-small'))) { env.localModelPath = local + '/'; env.allowRemoteModels = false; }
const w = new wf.WaveFile(fs.readFileSync(path.join(wd, 'audio.wav'))); w.toBitDepth('32f');
let s = w.getSamples(); if (Array.isArray(s)) s = s[0];
const audio = Float32Array.from(s);
const asr = await pipeline('automatic-speech-recognition', 'Xenova/whisper-small', {dtype: {encoder_model: 'q8', decoder_model_merged: 'q8'}});
const res = [];
for (const [a, b] of JSON.parse(fs.readFileSync(path.join(wd, 'islands.json')))) {
  const pa = Math.max(0, a - 0.15), pb = b + 0.15;
  const seg = audio.slice(Math.floor(pa * 16000), Math.floor(pb * 16000));
  const r = await asr(seg, {language: 'russian', task: 'transcribe', chunk_length_s: 30, stride_length_s: 5, return_timestamps: 'word'});
  const words = (r.chunks || []).map(c => ({text: c.text.trim(), t: +(pa + c.timestamp[0]).toFixed(3), end: +(pa + (c.timestamp[1] ?? c.timestamp[0])).toFixed(3)}));
  res.push({a, b, text: r.text.trim(), words});
  console.log(`[${a}-${b}] ${r.text.trim()}`);
}
fs.writeFileSync(path.join(wd, 'isl_words.json'), JSON.stringify(res, null, 1));
```

### `kit/scripts/make_base.py`

```python
"""make_base.py SRC WORKDIR 'a-b,a-b,...'
Cuts chosen takes (with inner pauses >0.35s removed), speeds x1.3, color, loudnorm -> base.mp4,
and maps word timings from isl_words.json to the output timeline -> words_out.json."""
import sys, json, subprocess, os
import numpy as np, wave

src, wd, takes_s = os.path.abspath(sys.argv[1]), sys.argv[2], sys.argv[3]
takes = [tuple(map(float, t.split('-'))) for t in takes_s.split(',')]
os.chdir(wd)
w = wave.open('audio.wav'); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
hop, win = 160, 400
n = (len(a) - win) // hop
db = np.array([20 * np.log10(np.sqrt(np.mean(a[i * hop:i * hop + win] ** 2)) + 1e-9) for i in range(n)])
keep = []
for A, B in takes:
    i0, i1 = int(A * 100), int(B * 100)
    sp = db[i0:i1] > -60
    runs = []; s = None
    for k, v in enumerate(sp):
        if v and s is None: s = k
        if not v and s is not None: runs.append([s, k]); s = None
    if s is not None: runs.append([s, len(sp)])
    m = []
    for r in runs:
        if m and r[0] - m[-1][1] < 35: m[-1][1] = r[1]
        else: m.append(r)
    m = [r for r in m if r[1] - r[0] >= 6]
    for k_, r in enumerate(m):
        end = A + r[1] / 100 + 0.08
        if k_ == len(m) - 1:
            # take end: extend until real silence (catches quiet final plosives like -к, -т), max +0.4s
            j = int(end * 100); lim = j + 40
            while j < lim and j + 5 < len(db) and db[j:j + 5].max() > -72: j += 1
            end = max(end, j / 100 + 0.04)
        keep.append([round(A + r[0] / 100 - 0.08, 3), round(end, 3)])
k2 = []
for r in keep:
    if k2 and r[0] <= k2[-1][1]: k2[-1][1] = max(k2[-1][1], r[1])
    else: k2.append(r)
keep = k2
json.dump(keep, open('keep.json', 'w'))
print('keep', keep, 'raw sum', round(sum(b - a for a, b in keep), 2))

# iPhone shoots HDR (HLG / Dolby Vision) by default: without tone mapping the reel looks washed-out and grey
trc = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=color_transfer', '-of', 'csv=p=0', src], text=True).strip()
TONE = ''
if trc in ('arib-std-b67', 'smpte2084'):
    if ' zscale ' in subprocess.run(['ffmpeg', '-hide_banner', '-filters'], capture_output=True, text=True).stdout:
        TONE = 'zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,'
        print('HDR source (' + trc + '): tone mapping to SDR')
    else:
        print('WARNING: HDR source, but this ffmpeg has no zscale filter - colours will look washed-out. Install ffmpeg with zimg (e.g. brew install ffmpeg).')
lst = open('list.txt', 'w')
durs = []
for i, (s0, s1) in enumerate(keep):
    subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', str(s0), '-to', str(s1), '-i', src, '-map', '0:v:0', '-map', '0:a:0',
                    '-vf', TONE + 'fps=30,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,format=yuv420p', '-af', 'afade=t=in:d=0.02', '-c:v', 'libx264', '-crf', '14', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
                    '-preset', 'veryfast', '-threads', '2', '-c:a', 'pcm_s16le', f'seg_{i}.mov'], check=True)
    lst.write(f"file 'seg_{i}.mov'\n")
    durs.append(float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f'seg_{i}.mov'])))
lst.close()
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'joined.mov'], check=True)
# loudness: exact -14 LUFS. Gain + soft peak limiter at -1.5 dB, gain refined by measuring the limited result
# (one-pass loudnorm undershoots by 2-4 dB; linear loudnorm is blocked by single peaks)
def lufs(chain):
    r = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-y', '-i', 'joined.mov', '-vn', '-af', f'atempo=1.3,{chain}loudnorm=print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True, check=True).stderr
    return float(json.loads(r[r.rindex('{'):r.rindex('}') + 1])['input_i'])
gain = -14 - lufs('')
for _ in range(3):
    LN = f'aresample=48000,volume={gain:.2f}dB,alimiter=limit=0.84:attack=2:release=60:level=false'
    err = -14 - lufs(LN + ',')
    if abs(err) < 0.3: break
    gain += err
print('loudness gain', round(gain, 1), 'dB')
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', 'joined.mov', '-filter_complex',
                "[0:v]setpts=PTS/1.3,fps=30,eq=brightness=-0.02:contrast=1.03,colorbalance=rm=0.015:bm=-0.015,curves=all='0/0 0.25/0.235 1/1',unsharp=5:5:0.2,format=yuv420p[vo];"
                f"[0:a]atempo=1.3,{LN},aresample=48000[ao]",
                '-map', '[vo]', '-map', '[ao]', '-c:v', 'libx264', '-crf', '18', '-preset', 'medium', '-threads', '2', '-c:a', 'aac', '-b:a', '192k', 'base.mp4'], check=True)
dur = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', 'base.mp4']))
offs = []; o = 0
for d in durs: offs.append(o); o += d

def mp(t):
    for i, (s0, s1) in enumerate(keep):
        if s0 - 0.3 <= t <= s1 + 0.3:
            return round((offs[i] + min(max(t - s0, 0), durs[i])) / 1.3, 3)
    return None

isl = json.load(open('isl_words.json'))
out = []
for it in isl:
    if any(k in it['text'] for k in ('Игорь Негода', 'Субтитры', 'Спасибо.', 'Смешно')): continue
    for wd_ in it['words']:
        if any(A <= wd_['t'] <= B for A, B in takes):
            out.append({'text': wd_['text'], 't': mp(wd_['t']), 'end': mp(wd_['end'])})
json.dump(out, open('words_out.json', 'w'), ensure_ascii=False)
json.dump({'duration': dur}, open('meta.json', 'w'))
print('duration', dur)
for i, x in enumerate(out):
    print(i, x['t'], x['text'])
for f in os.listdir('.'):
    if f.startswith('seg_') or f == 'joined.mov':
        os.remove(f)
```

### `kit/scripts/declick.py`

```python
"""declick.py IN.wav OUT.wav
Removes wet mouth clicks: finds very short (<=~6ms) high-frequency impulses that stand >14dB above
their neighbourhood and subtracts ONLY the >4kHz component in a ~7ms window around each one.
Voice body (low/mid frequencies) and word endings stay intact."""
import sys, numpy as np, wave
from scipy.signal import butter, sosfiltfilt
inp, outp = sys.argv[1], sys.argv[2]
w = wave.open(inp); sr = w.getframerate(); ch = w.getnchannels()
raw = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float).reshape(-1, ch) / 32768
mono = raw.mean(1)
sos = butter(6, 4000, 'hp', fs=sr, output='sos')
hop = int(0.002 * sr)
hm = sosfiltfilt(sos, mono); n = len(hm) // hop
eh = 20 * np.log10(np.sqrt((hm[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9)
spikes = []
for i in range(10, n - 10):
    nb = np.r_[eh[i - 8:i - 2], eh[i + 3:i + 9]]
    if eh[i] - np.median(nb) > 14 and eh[i] == eh[i - 2:i + 3].max() and eh[i] > -50:
        spikes.append(i)
g = np.ones(len(mono))
pre, post, fade = int(0.003 * sr), int(0.004 * sr), int(0.0015 * sr)
for i in spikes:
    c = i * hop + hop // 2
    s0, s1 = max(0, c - pre), min(len(g), c + post)
    win = np.full(s1 - s0, 0.08)
    win[:fade] = np.linspace(1, 0.08, fade); win[-fade:] = np.linspace(0.08, 1, fade)
    g[s0:s1] = np.minimum(g[s0:s1], win)
out = np.empty_like(raw)
for k in range(ch):
    hk = sosfiltfilt(sos, raw[:, k])
    out[:, k] = raw[:, k] - hk * (1 - g)
o = wave.open(outp, 'wb'); o.setnchannels(ch); o.setsampwidth(2); o.setframerate(sr)
o.writeframes((out * 32768).clip(-32768, 32767).astype(np.int16).tobytes()); o.close()
print('clicks removed:', len(spikes))
```

### `kit/scripts/common.py`

```python
import json, re
from PIL import ImageFont

import os
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XB = os.path.join(KIT, 'remotion', 'public', 'fonts', 'Montserrat-ExtraBold.ttf')
BK = os.path.join(KIT, 'remotion', 'public', 'fonts', 'Montserrat-Medium.ttf')
MAXW = 900

CENSOR = {'денег': 'д*нег', 'деньгами': 'д*ньгами', 'деньги': 'д*ньги', 'деньгах': 'д*ньгах', 'деньгам': 'д*ньгам',
          'бюджета': 'бюдж*та', 'бюджет': 'бюдж*т', 'бюджете': 'бюдж*те', 'бюджету': 'бюдж*ту',
          'стоимость': 'ст*имость', 'стоимости': 'ст*имости', 'стоит': 'ст*ит', 'рублей': 'р*блей', 'рубля': 'р*бля', 'рубль': 'р*бль',
          'бесплатно': 'бесплатн*', 'оплата': 'опл*та', 'оплату': 'опл*ту', 'оплаты': 'опл*ты'}
# words from the brief «ЦЕНЗУРА:» -> add here in props.py:  CENSOR['слово'] = 'сл*во'


def censor(text):
    """Censor every CENSOR word in any on-screen string, keeping its capitalisation (Деньги -> Д*ньги, ДЕНЬГИ -> Д*НЬГИ)."""
    def rep(m):
        w = m.group(0); c = CENSOR.get(w.lower())
        if not c: return w
        if w.isupper() and len(w) > 1: return c.upper()
        return c[0].upper() + c[1:] if w[0].isupper() else c
    return re.sub(r'[А-Яа-яЁё]+', rep, text)


YO = {'еще': 'ещё', 'ее': 'её', 'продает': 'продаёт', 'продается': 'продаётся', 'трех': 'трёх', 'офер': 'оффер'}


def fit(text, font, size, maxw=MAXW):
    while size > 20:
        if ImageFont.truetype(font, size).getlength(text) <= maxw:
            return size
        size -= 2
    return size


def load_words(path, fixes=None):
    raw = json.load(open(path))
    words = []
    for w in raw:
        txt = re.sub(r'[.,!?;:…«»"]', '', w['text']).strip()
        if not txt:
            continue
        words.append({'t': w['t'], 'end': w['end'], 'text': txt})
    # fill missing timings
    for i, w in enumerate(words):
        if w['t'] is None:
            w['t'] = words[i - 1]['end'] + 0.05 if i else 0
        if w['end'] is None:
            w['end'] = w['t'] + 0.3
    for i in range(1, len(words)):  # monotonic
        if words[i]['t'] < words[i - 1]['t']:
            words[i]['t'] = words[i - 1]['t'] + 0.05
    words[0]['t'] = 0.0
    return words


def replace_seq(words, old, new):
    """replace consecutive tokens `old` (list, case-insensitive) by `new` (list)."""
    lo = [o.lower() for o in old]
    i = 0
    while i <= len(words) - len(old):
        if [w['text'].lower() for w in words[i:i + len(old)]] == lo:
            span = words[i:i + len(old)]
            if len(new) == len(old):
                rep = [{'t': s['t'], 'end': s['end'], 'text': n} for s, n in zip(span, new)]
            else:
                t0, t1 = span[0]['t'], span[-1]['end']
                step = (t1 - t0) / len(new)
                rep = [{'t': round(t0 + k * step, 3), 'end': round(t0 + (k + 1) * step, 3), 'text': n} for k, n in enumerate(new)]
            words[i:i + len(old)] = rep
            i += len(new)
        else:
            i += 1
    return words


def finalize(words, pink):
    for w in words:
        base = w['text']
        if base.lower() in YO:
            r = YO[base.lower()]
            w['text'] = r[0].upper() + r[1:] if base[0].isupper() else r
        low = w['text'].lower()
        w['text'] = censor(w['text'])
        w['pink'] = low in pink or w['text'].lower() in pink
    return words


def finder(words):
    def T(word, nth=1):
        c = 0
        for w in words:
            if w['text'].lower() == word.lower():
                c += 1
                if c == nth:
                    return w['t']
        raise KeyError(word)
    return T


def hook(lines, accent, end):
    acc_lines = accent.split('\n')
    ls = min(fit(l, XB, 68) for l in lines)
    asz = min(fit(a, XB, 145) for a in acc_lines)
    h = len(lines) * ls * 0.95 + 6 + asz * 0.98 * len(acc_lines)
    return {'lines': lines, 'accent': accent, 'lineSize': ls, 'accentSize': asz, 'top': int(545 - h), 'end': end}


def thesis(t, end, label, title, size=72):
    return {'type': 'thesis', 't': t, 'end': end, 'label': label, 'title': title, 'size': fit(title, XB, size)}


def punch(t, end, text):
    return {'type': 'punch', 't': t, 'end': end, 'text': text, 'size': fit(text, XB, 90)}


def _cz(x, key=None):
    """apply censor() to every text field of hook / overlays (titles, labels, items, card texts...)."""
    if isinstance(x, dict): return {k: _cz(v, k) for k, v in x.items()}
    if isinstance(x, list): return [_cz(v, key) for v in x]
    if isinstance(x, str) and key in ('text', 'title', 'label', 'tag', 'before', 'accent', 'lines', 'badge'): return censor(x)
    return x


def save(path, video, duration, hk, words, ov, zooms):
    hk, ov = _cz(hk), _cz(ov)   # censorship on ALL on-screen text, not only subtitles
    words = [{**w, 'text': censor(w['text'])} for w in words]
    props = {'video': video, 'duration': duration, 'face': {'cx': 530, 'cy': 820}, 'hook': hk,
             'words': words, 'overlays': ov, 'zooms': zooms}
    json.dump(props, open(path, 'w'), ensure_ascii=False, indent=1)
    print('hook', hk['lines'], hk['accent'].replace('\n', ' / '), hk['lineSize'], hk['accentSize'])
    for o in ov:
        print(f"{o['type']:16s} {o['t']:6.2f}-{min(o['end'], 99):6.2f}  {o.get('title', o.get('text', ''))}")
    print('SUBS:', ' '.join(w['text'] for w in words))
```

### `kit/scripts/setup_assets.py`

```python
"""setup_assets.py [WORKFOLDER]
Puts Montserrat-ExtraBold.ttf, Montserrat-Medium.ttf and gradient-niz.png into kit/remotion/public/.
1) takes them from WORKFOLDER (fonts/, assets/, root, any subfolder) if the user put them there;
2) otherwise downloads Montserrat from npm (@expo-google-fonts/montserrat, OFL; identical to Google Fonts)
   and draws the gradient (black, alpha rising linearly to the bottom - same as the original Figma file)."""
import sys, os, shutil, subprocess, tempfile, glob, tarfile
import numpy as np
from PIL import Image

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUB = os.path.join(KIT, 'remotion', 'public')
FON = os.path.join(PUB, 'fonts')
os.makedirs(FON, exist_ok=True)
work = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(KIT)
need = {'Montserrat-ExtraBold.ttf': os.path.join(FON, 'Montserrat-ExtraBold.ttf'),
        'Montserrat-Medium.ttf': os.path.join(FON, 'Montserrat-Medium.ttf'),
        'gradient-niz.png': os.path.join(PUB, 'gradient-niz.png')}


def find(name):
    for p in glob.glob(os.path.join(work, '**', name), recursive=True):
        if os.path.abspath(p) != need[name] and 'node_modules' not in p:
            return p


for name, dst in need.items():
    if os.path.exists(dst):
        print('ok   ', name); continue
    src = find(name)
    if src:
        shutil.copy(src, dst); print('copy ', name, '<-', src)

missing_fonts = [n for n in ('Montserrat-ExtraBold.ttf', 'Montserrat-Medium.ttf') if not os.path.exists(need[n])]
if missing_fonts:
    tmp = tempfile.mkdtemp()
    subprocess.run('npm pack @expo-google-fonts/montserrat@0.4.1', shell=True, cwd=tmp, check=True, capture_output=True)
    with tarfile.open(glob.glob(os.path.join(tmp, '*.tgz'))[0]) as t:
        t.extractall(tmp, filter='data') if hasattr(tarfile, 'data_filter') else t.extractall(tmp)
    src = {'Montserrat-ExtraBold.ttf': '800ExtraBold/Montserrat_800ExtraBold.ttf', 'Montserrat-Medium.ttf': '500Medium/Montserrat_500Medium.ttf'}
    for n in missing_fonts:
        shutil.copy(os.path.join(tmp, 'package', src[n]), need[n]); print('npm  ', n)
    shutil.rmtree(tmp, ignore_errors=True)

if not os.path.exists(need['gradient-niz.png']):
    W, H = 2160, 2036                       # shown at width 1080 -> bottom 1018 px of the frame
    y = np.arange(H, dtype=float)
    alpha = np.clip(0.06241 * y - 30.116, 0, 255).round().astype(np.uint8)
    img = np.zeros((H, W, 4), np.uint8); img[:, :, 3] = alpha[:, None]
    Image.fromarray(img, 'RGBA').save(need['gradient-niz.png']); print('drew  gradient-niz.png')

print('assets ready in', PUB)
```

### `kit/scripts/qa.sh`

```bash
#!/bin/bash
# qa.sh PROPS.json OUTDIR frame1 frame2 ...  -> OUTDIR/qa_sheet.jpg (4 per row) via Remotion stills
# Stops with the Remotion error text if any frame fails to render.
set -e
P=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); O=$2; shift 2; mkdir -p "$O"; O=$(cd "$O" && pwd)
cd "$(dirname "$0")/../remotion"
for f in "$@"; do
  rm -f "$O/q$f.png"
  if ! npx remotion still src/index.ts Reel "$O/q$f.png" --frame=$f --props="$P" --log=error > "$O/still.log" 2>&1 || [ ! -s "$O/q$f.png" ]; then
    echo "ОШИБКА: кадр $f не отрисовался:"; tail -20 "$O/still.log"; exit 1
  fi
done
python3 - "$O" "$@" <<'PY'
import sys; from PIL import Image
o, fr = sys.argv[1], sys.argv[2:]
ims = [Image.open(f'{o}/q{f}.png').convert('RGB').resize((360, 640)) for f in fr]
cols = 4; rows = (len(ims) + cols - 1) // cols
sheet = Image.new('RGB', (360 * cols, 640 * rows), 'black')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * 360, (i // cols) * 640))
sheet.save(f'{o}/qa_sheet.jpg', quality=88)
PY
echo "$O/qa_sheet.jpg"
```

### Пример `WD/props.py`

```python
import sys, json; sys.path.insert(0, 'ПУТЬ/kit/scripts')
from common import *
# CENSOR['слово'] = 'сл*во'                                   # слова из ТЗ «ЦЕНЗУРА:»
WD = 'ПУТЬ/kit/work/offer'
W = load_words(f'{WD}/words_out.json')
W = replace_seq(W, ['Вы', 'могу'], ['Я', 'могу'])            # ошибки распознавания
W = finalize(W, {'оффер', 'результат', 'сроки'})               # ключевые слова (жирные в субтитрах)
T = finder(W)                                                  # T('слово', n) -> время n-го вхождения
dur = json.load(open(f'{WD}/meta.json'))['duration']
hk = hook(['ОФФЕР, ПЕРЕД КОТОРЫМ', 'НЕ УСТОИТ'], 'КЛИЕНТ', end=T('перед') - 0.1)
ov = [
  thesis(T('Забудьте'), T('Идеальный') - 0.25, 'забудьте про', 'ПРОГРЕВЫ НА 2 МЕСЯЦА'),
  {'type': 'cardList', 't': T('конкретный'), 'end': T('Вместо') - 0.3, 'title': 'Формула оффера', 'tag': '3 ЭЛЕМЕНТА',
   'items': [{'t': T('конкретный'), 'text': 'конкретный результат'}, {'t': T('Понятные'), 'text': 'понятные сроки'}]},
  {'type': 'cardBeforeAfter', 'pos': 'bottom', 'bottom': 50, 't': T('Вместо'), 'end': T('Клиенту') - 0.3,
   'title': 'Как сказать', 'tag': 'ПРИМЕР', 'before': '«Я маркетолог»', 'afterT': T('могу'),
   'after': [{'text': '«Привлеку '}, {'text': 'от 30 заявок в день', 'hl': True, 'badge': 'результат'}, {'br': True},
             {'text': 'за 14 дней', 'hl': True, 'badge': 'срок'}, {'text': '»'}]},
  {'type': 'cardQuote', 't': ..., 'end': ..., 'title': 'Напишите так', 'tag': 'ОДНА ФРАЗА', 'words': [{'t': ..., 'text': '«Сейчас'}, ...]},
  {'type': 'cardIcons', 't': ..., 'end': ..., 'width': 860, 'people': [{'label': 'клиент'}, {'label': 'вы', 'accent': {'t': ..., 'text': 'глубоко в процессе'}}]},
  {'type': 'dots', 't': ..., 'end': ..., 'items': [{'t': ..., 'text': 'результат'}]},
  punch(T('ему'), T('Проверьте') - 0.15, 'НУЖЕН РЕЗУЛЬТАТ'),
  thesis(T('сохраните'), 99, 'сохраните, чтобы', 'ПЕРЕПИСАТЬ ОФФЕР СЕГОДНЯ'),
]
zooms = [{'t': T('Забудьте'), 'scale': 1.05}, {'t': T('Идеальный'), 'scale': 1.0}]
save(f'{WD}/props.json', 'offer.mp4', dur, hk, W, ov, zooms)   # 'offer.mp4' лежит в kit/remotion/public/
```