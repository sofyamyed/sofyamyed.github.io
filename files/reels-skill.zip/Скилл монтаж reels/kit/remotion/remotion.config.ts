import {Config} from '@remotion/cli/config';
// If Remotion cannot download its own headless Chrome, point it to an installed Chrome/Chromium, e.g.:
//   macOS:   Config.setBrowserExecutable('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome');
//   Windows: Config.setBrowserExecutable('C:/Program Files/Google/Chrome/Application/chrome.exe');
//   Linux:   Config.setBrowserExecutable('/usr/bin/chromium');
Config.setVideoImageFormat('jpeg');
