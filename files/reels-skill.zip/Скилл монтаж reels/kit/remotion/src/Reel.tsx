import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Img, OffthreadVideo, staticFile, useCurrentFrame, useVideoConfig, delayRender, continueRender} from 'remotion';

const PINK = '#FF2A94';
const WHITE = '#FFFFFF';
const DARK = '#151515';
const LIGHT = '#F7F6F4';
const XB = 'MontserratXB';
const BK = 'MontserratMedium';
const SHADOW = '0 4px 18px rgba(0,0,0,.25)';

const clamp = (x: number) => Math.max(0, Math.min(1, x));
const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
const smooth = (x: number) => {const c = clamp(x); return c * c * (3 - 2 * c);};

// opacity / progress for an element living in [t, end]
const life = (now: number, t: number, end: number, inDur = 0.2, outDur = 0.2) => {
  if (now < t || now > end + outDur) return {o: 0, p: 0};
  const p = easeOut((now - t) / inDur);
  const out = now > end ? 1 - clamp((now - end) / outDur) : 1;
  return {o: Math.min(p, out), p};
};

const FontLoader: React.FC = () => {
  const [handle] = useState(() => delayRender('fonts'));
  useEffect(() => {
    const a = new FontFace(XB, `url(${staticFile('fonts/Montserrat-ExtraBold.ttf')})`);
    const b = new FontFace(BK, `url(${staticFile('fonts/Montserrat-Medium.ttf')})`);
    Promise.all([a.load(), b.load()]).then((fs) => {
      fs.forEach((f) => (document.fonts as any).add(f));
      continueRender(handle);
    });
  }, [handle]);
  return null;
};

type Word = {t: number; end: number; text: string; pink?: boolean};

// ---------- HOOK ----------
const Hook: React.FC<{now: number; h: any}> = ({now, h}) => {
  const out = now > h.end ? 1 - clamp((now - h.end) / 0.15) : 1;
  if (out <= 0) return null;
  return (
    <div style={{position: 'absolute', top: h.top, left: 0, width: 1080, textAlign: 'center', opacity: out, textShadow: SHADOW}}>
      {h.lines.map((l: string, i: number) => (
        <div key={i} style={{fontFamily: XB, fontSize: h.lineSize, lineHeight: 0.95, color: WHITE, letterSpacing: 0.5}}>{l}</div>
      ))}
      {String(h.accent).split('\n').map((a: string, i: number) => <div key={'a' + i} style={{fontFamily: XB, fontSize: h.accentSize, lineHeight: 0.98, color: PINK, marginTop: i ? 0 : 6}}>{a}</div>)}
    </div>
  );
};

// ---------- THESIS ----------
const Thesis: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op, p} = life(now, o.t, o.end);
  if (op <= 0) return null;
  return (
    <div style={{position: 'absolute', top: o.top ?? 330, left: 0, width: 1080, textAlign: 'center', opacity: op, transform: `translateY(${(1 - p) * 16}px)`, textShadow: SHADOW}}>
      <div style={{fontFamily: BK, fontSize: 30, color: WHITE, marginBottom: 6}}>{o.label}</div>
      <div style={{fontFamily: XB, fontSize: o.size ?? 72, lineHeight: 1, color: PINK}}>{o.title}</div>
    </div>
  );
};

// ---------- PUNCH ----------
const Punch: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op, p} = life(now, o.t, o.end, 0.18);
  if (op <= 0) return null;
  const line = smooth((now - o.t - 0.12) / 0.25);
  return (
    <div style={{position: 'absolute', top: o.top ?? 1400, left: 0, width: 1080, display: 'flex', justifyContent: 'center', opacity: op, transform: `scale(${0.96 + 0.04 * p})`}}>
      <div style={{display: 'inline-block'}}>
        <div style={{fontFamily: XB, fontSize: o.size ?? 90, lineHeight: 1, color: WHITE, textShadow: SHADOW, whiteSpace: 'nowrap'}}>{o.text}</div>
        <div style={{height: 11, background: PINK, borderRadius: 6, marginTop: 15, width: `${line * 100}%`}} />
      </div>
    </div>
  );
};

// ---------- DOTS ----------
const Dots: React.FC<{now: number; o: any}> = ({now, o}) => {
  const {o: op} = life(now, o.t, o.end);
  if (op <= 0) return null;
  return (
    <div style={{position: 'absolute', top: o.top ?? 330, left: 0, width: 1080, textAlign: 'center', opacity: op, textShadow: SHADOW}}>
      {o.items.map((it: any, i: number) => {
        const q = easeOut((now - it.t) / 0.2);
        return (
          <div key={i} style={{fontFamily: BK, fontSize: 44, lineHeight: 1.6, color: WHITE, opacity: q, transform: `translateY(${(1 - q) * 10}px)`}}>
            <span style={{display: 'inline-block', width: 10, height: 10, borderRadius: 5, background: PINK, marginRight: 16, verticalAlign: 'middle'}} />
            {it.text}
          </div>
        );
      })}
    </div>
  );
};

// ---------- CARDS ----------
const CardShell: React.FC<{now: number; o: any; dark?: boolean; children: React.ReactNode}> = ({now, o, dark, children}) => {
  const {o: op, p} = life(now, o.t, o.end, 0.28, 0.2);
  if (op <= 0) return null;
  const w = o.width ?? 820;
  return (
    <div style={{position: 'absolute', ...(o.pos === 'bottom' ? {bottom: o.bottom ?? 170} : {top: o.top ?? 140}), left: (1080 - w) / 2, width: w, boxSizing: 'border-box', padding: 36, borderRadius: 24,
      background: dark ? DARK : LIGHT, color: dark ? WHITE : '#111', boxShadow: '0 10px 40px rgba(0,0,0,.25)',
      opacity: op, transform: `translateY(${(1 - p) * 24}px) scale(${0.97 + 0.03 * p})`}}>
      {children}
    </div>
  );
};

const Tag: React.FC<{text: string}> = ({text}) => (
  <div style={{background: PINK, color: WHITE, fontFamily: XB, fontSize: 24, padding: '8px 18px', borderRadius: 30, letterSpacing: 0.5, whiteSpace: 'nowrap'}}>{text}</div>
);

const CardHeader: React.FC<{title: string; tag?: string}> = ({title, tag}) => (
  <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22}}>
    <div style={{fontFamily: XB, fontSize: 42}}>{title}</div>
    {tag ? <Tag text={tag} /> : null}
  </div>
);

const reveal = (now: number, t: number) => easeOut((now - t) / 0.18);

const CardList: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={o}>
    <CardHeader title={o.title} tag={o.tag} />
    {o.items.map((it: any, i: number) => (
      <div key={i} style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 14, opacity: reveal(now, it.t)}}>
        <div style={{border: `2px solid ${PINK}`, color: PINK, borderRadius: 8, fontFamily: XB, fontSize: 20, padding: '4px 8px'}}>{String(i + 1).padStart(2, '0')}</div>
        <div style={{fontFamily: BK, fontSize: 38}}>{it.text}</div>
      </div>
    ))}
  </CardShell>
);

const CardQuote: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={o}>
    <CardHeader title={o.title} tag={o.tag} />
    <div style={{display: 'flex', gap: 22}}>
      <div style={{width: 6, borderRadius: 3, background: PINK, minHeight: o.minHeight ?? 150}} />
      <div style={{fontFamily: BK, fontSize: 40, lineHeight: 1.4}}>
        {o.words.map((w: any, i: number) => (
          <span key={i} style={{opacity: now >= w.t ? 1 : 0, color: w.pink ? PINK : undefined}}>{w.text} </span>
        ))}
      </div>
    </div>
  </CardShell>
);

const CardBeforeAfter: React.FC<{now: number; o: any}> = ({now, o}) => {
  const q = reveal(now, o.afterT);
  return (
    <CardShell now={now} o={o}>
      <CardHeader title={o.title} tag={o.tag} />
      <div style={{fontFamily: BK, fontSize: 26, color: '#8a8a8a'}}>было:</div>
      <div style={{fontFamily: BK, fontSize: 38, color: '#8a8a8a', textDecoration: 'line-through', textDecorationColor: PINK, marginTop: 4}}>{o.before}</div>
      <div style={{opacity: q, marginTop: 20}}>
        <div style={{fontFamily: BK, fontSize: 26, color: '#8a8a8a'}}>стало:</div>
        <div style={{fontFamily: BK, fontSize: 38, lineHeight: 2.2, marginTop: 10}}>
          {o.after.map((s: any, i: number) => s.hl ? (
            <span key={i} style={{position: 'relative', background: 'rgba(255,42,148,.25)', borderRadius: 6, padding: '0 4px'}}>
              {s.badge ? <span style={{position: 'absolute', top: -31, left: 0, background: PINK, color: WHITE, fontFamily: XB, fontSize: 15, padding: '2px 8px', lineHeight: 1.3, borderRadius: 20, whiteSpace: 'nowrap'}}>{s.badge}</span> : null}
              {s.text}
            </span>
          ) : s.br ? <br key={i} /> : <span key={i}>{s.text}</span>)}
        </div>
      </div>
    </CardShell>
  );
};

const Person: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={WHITE} strokeWidth={2.2}>
    <circle cx="50" cy="34" r="18" />
    <path d="M14 92c4-20 18-30 36-30s32 10 36 30" />
  </svg>
);

const CardIcons: React.FC<{now: number; o: any}> = ({now, o}) => (
  <CardShell now={now} o={{...o, width: o.width ?? 640}} dark>
    <div style={{display: 'flex', justifyContent: 'space-around', alignItems: 'flex-end', paddingTop: 30}}>
      {o.people.map((pp: any, i: number) => {
        const q = reveal(now, pp.t ?? o.t);
        const acc = pp.accent ? reveal(now, pp.accent.t) : 0;
        return (
          <div key={i} style={{textAlign: 'center', opacity: q, position: 'relative'}}>
            {pp.accent ? (
              <div style={{position: 'absolute', top: -34, left: 0, right: 0, opacity: acc, fontFamily: XB, fontSize: 22, color: WHITE, whiteSpace: 'nowrap'}}>{pp.accent.text}</div>
            ) : null}
            <div style={{position: 'relative'}}>
              <Person size={150} />
              {pp.accent ? <div style={{position: 'absolute', top: 30, left: 88, width: 26, height: 26, borderRadius: 13, background: PINK, opacity: acc, boxShadow: `0 0 18px ${PINK}`}} /> : null}
            </div>
            <div style={{fontFamily: BK, fontSize: 34, marginTop: 10}}>{pp.label}</div>
          </div>
        );
      })}
    </div>
  </CardShell>
);

const CardProgress: React.FC<{now: number; o: any}> = ({now, o}) => {
  const fill = smooth((now - o.t - 0.2) / 0.8) * o.percent;
  return (
    <CardShell now={now} o={{...o, width: o.width ?? 640}} dark>
      <div style={{fontFamily: XB, fontSize: 26, textAlign: 'center'}}>{o.title}</div>
      <div style={{height: 14, background: '#333', borderRadius: 7, marginTop: 22, overflow: 'hidden'}}>
        <div style={{height: '100%', width: `${fill}%`, background: PINK, borderRadius: 7}} />
      </div>
      <div style={{textAlign: 'right', fontFamily: BK, fontSize: 18, marginTop: 6}}>{Math.round(fill)}%</div>
      {(o.items || []).map((it: any, i: number) => (
        <div key={i} style={{fontFamily: BK, fontSize: 26, marginTop: 14, opacity: reveal(now, it.t)}}>▫ {it.text}</div>
      ))}
    </CardShell>
  );
};

// ---------- SUBTITLES ----------
const Subs: React.FC<{now: number; words: Word[]}> = ({now, words}) => {
  let cur: Word | null = null;
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const next = words[i + 1];
    const until = Math.min(next ? next.t : Infinity, w.end + 0.6);
    if (now >= w.t && now < until) {cur = w; break;}
  }
  if (!cur) return null;
  const q = easeOut((now - cur.t) / 0.08);
  return (
    <div style={{position: 'absolute', top: 1640 - 40, left: 0, width: 1080, height: 80, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{fontFamily: cur.pink ? XB : BK, fontSize: cur.pink ? 64 : 60, color: WHITE, opacity: q, transform: `scale(${0.92 + 0.08 * q})`, textShadow: '0 2px 14px rgba(0,0,0,.45)'}}>{cur.text}</div>
    </div>
  );
};

// ---------- ZOOM ----------
const zoomAt = (now: number, zooms: {t: number; scale: number}[]) => {
  let s = 1;
  for (const z of zooms) {
    if (now < z.t) break;
    const k = smooth((now - z.t) / 0.45);
    s = s + (z.scale - s) * k;
  }
  return s;
};

export const Reel: React.FC<any> = (props) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const now = frame / fps;
  const zs = zoomAt(now, props.zooms || []);
  const face = props.face || {cx: 540, cy: 820};
  const C: Record<string, React.FC<{now: number; o: any}>> = {
    thesis: Thesis, punch: Punch, dots: Dots, cardList: CardList, cardQuote: CardQuote,
    cardBeforeAfter: CardBeforeAfter, cardIcons: CardIcons, cardProgress: CardProgress,
  };
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <FontLoader />
      <AbsoluteFill style={{transform: `scale(${zs})`, transformOrigin: `${face.cx}px ${face.cy}px`}}>
        <OffthreadVideo src={staticFile(props.video || 'base.mp4')} />
      </AbsoluteFill>
      <Img src={staticFile('gradient-niz.png')} style={{position: 'absolute', bottom: 0, left: 0, width: 1080}} />
      {(props.overlays || []).filter((o: any) => o.type !== 'punch').map((o: any, i: number) => {
        const Comp = C[o.type];
        return Comp ? <Comp key={i} now={now} o={o} /> : null;
      })}
      {(props.overlays || []).filter((o: any) => o.type === 'punch').map((o: any, i: number) => <Punch key={'p' + i} now={now} o={o} />)}
      {props.hook ? <Hook now={now} h={props.hook} /> : null}
      {(props.overlays || []).some((o: any) => o.pos === 'bottom' && now >= o.t - 0.05 && now <= o.end + 0.2) ? null : <Subs now={now} words={props.words || []} />}
    </AbsoluteFill>
  );
};
