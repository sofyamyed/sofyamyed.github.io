import React from 'react';
import {Composition} from 'remotion';
import {Reel} from './Reel';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Reel"
    component={Reel as any}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={300}
    defaultProps={{duration: 10, words: [], overlays: [], zooms: [], face: {cx: 540, cy: 820}} as any}
    calculateMetadata={({props}: any) => ({durationInFrames: Math.round((props.duration || 10) * 30)})}
  />
);
