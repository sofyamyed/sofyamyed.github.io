import json, re
from PIL import ImageFont

import os
KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XB = os.path.join(KIT, 'remotion', 'public', 'fonts', 'Montserrat-ExtraBold.ttf')
BK = os.path.join(KIT, 'remotion', 'public', 'fonts', 'Montserrat-Medium.ttf')
MAXW = 900

CENSOR = {'денег': 'д*нег', 'деньгами': 'д*ньгами', 'деньги': 'д*ньги', 'деньгах': 'д*ньгах', 'деньгам': 'д*ньгам',
          'бюджета': 'бюдж*та', 'бюджет': 'бюдж*т', 'бюджете': 'бюдж*те', 'бюджету': 'бюдж*ту',
          'стоимость': 'ст*имость', 'стоимости': 'ст*имости', 'стоит': 'ст*ит', 'рублей': 'р*блей', 'рубля': 'р*бля', 'рубль': 'р*бль',
          'бесплатно': 'бесплатн*', 'оплата': 'опл*та', 'оплату': 'опл*ту', 'оплаты': 'опл*ты'}
# words from the brief «ЦЕНЗУРА:» -> add here in props.py:  CENSOR['слово'] = 'сл*во'


def censor(text):
    """Censor every CENSOR word in any on-screen string, keeping its capitalisation (Деньги -> Д*ньги, ДЕНЬГИ -> Д*НЬГИ)."""
    def rep(m):
        w = m.group(0); c = CENSOR.get(w.lower())
        if not c: return w
        if w.isupper() and len(w) > 1: return c.upper()
        return c[0].upper() + c[1:] if w[0].isupper() else c
    return re.sub(r'[А-Яа-яЁё]+', rep, text)


YO = {'еще': 'ещё', 'ее': 'её', 'продает': 'продаёт', 'продается': 'продаётся', 'трех': 'трёх', 'офер': 'оффер'}


def fit(text, font, size, maxw=MAXW):
    while size > 20:
        if ImageFont.truetype(font, size).getlength(text) <= maxw:
            return size
        size -= 2
    return size


def load_words(path, fixes=None):
    raw = json.load(open(path))
    words = []
    for w in raw:
        txt = re.sub(r'[.,!?;:…«»"]', '', w['text']).strip()
        if not txt:
            continue
        words.append({'t': w['t'], 'end': w['end'], 'text': txt})
    # fill missing timings
    for i, w in enumerate(words):
        if w['t'] is None:
            w['t'] = words[i - 1]['end'] + 0.05 if i else 0
        if w['end'] is None:
            w['end'] = w['t'] + 0.3
    for i in range(1, len(words)):  # monotonic
        if words[i]['t'] < words[i - 1]['t']:
            words[i]['t'] = words[i - 1]['t'] + 0.05
    words[0]['t'] = 0.0
    return words


def replace_seq(words, old, new):
    """replace consecutive tokens `old` (list, case-insensitive) by `new` (list)."""
    lo = [o.lower() for o in old]
    i = 0
    while i <= len(words) - len(old):
        if [w['text'].lower() for w in words[i:i + len(old)]] == lo:
            span = words[i:i + len(old)]
            if len(new) == len(old):
                rep = [{'t': s['t'], 'end': s['end'], 'text': n} for s, n in zip(span, new)]
            else:
                t0, t1 = span[0]['t'], span[-1]['end']
                step = (t1 - t0) / len(new)
                rep = [{'t': round(t0 + k * step, 3), 'end': round(t0 + (k + 1) * step, 3), 'text': n} for k, n in enumerate(new)]
            words[i:i + len(old)] = rep
            i += len(new)
        else:
            i += 1
    return words


def finalize(words, pink):
    for w in words:
        base = w['text']
        if base.lower() in YO:
            r = YO[base.lower()]
            w['text'] = r[0].upper() + r[1:] if base[0].isupper() else r
        low = w['text'].lower()
        w['text'] = censor(w['text'])
        w['pink'] = low in pink or w['text'].lower() in pink
    return words


def finder(words):
    def T(word, nth=1):
        c = 0
        for w in words:
            if w['text'].lower() == word.lower():
                c += 1
                if c == nth:
                    return w['t']
        raise KeyError(word)
    return T


def hook(lines, accent, end):
    acc_lines = accent.split('\n')
    ls = min(fit(l, XB, 68) for l in lines)
    asz = min(fit(a, XB, 145) for a in acc_lines)
    h = len(lines) * ls * 0.95 + 6 + asz * 0.98 * len(acc_lines)
    return {'lines': lines, 'accent': accent, 'lineSize': ls, 'accentSize': asz, 'top': int(545 - h), 'end': end}


def thesis(t, end, label, title, size=72):
    return {'type': 'thesis', 't': t, 'end': end, 'label': label, 'title': title, 'size': fit(title, XB, size)}


def punch(t, end, text):
    return {'type': 'punch', 't': t, 'end': end, 'text': text, 'size': fit(text, XB, 90)}


def _cz(x, key=None):
    """apply censor() to every text field of hook / overlays (titles, labels, items, card texts...)."""
    if isinstance(x, dict): return {k: _cz(v, k) for k, v in x.items()}
    if isinstance(x, list): return [_cz(v, key) for v in x]
    if isinstance(x, str) and key in ('text', 'title', 'label', 'tag', 'before', 'accent', 'lines', 'badge'): return censor(x)
    return x


def save(path, video, duration, hk, words, ov, zooms):
    hk, ov = _cz(hk), _cz(ov)   # censorship on ALL on-screen text, not only subtitles
    words = [{**w, 'text': censor(w['text'])} for w in words]
    props = {'video': video, 'duration': duration, 'face': {'cx': 530, 'cy': 820}, 'hook': hk,
             'words': words, 'overlays': ov, 'zooms': zooms}
    json.dump(props, open(path, 'w'), ensure_ascii=False, indent=1)
    print('hook', hk['lines'], hk['accent'].replace('\n', ' / '), hk['lineSize'], hk['accentSize'])
    for o in ov:
        print(f"{o['type']:16s} {o['t']:6.2f}-{min(o['end'], 99):6.2f}  {o.get('title', o.get('text', ''))}")
    print('SUBS:', ' '.join(w['text'] for w in words))
