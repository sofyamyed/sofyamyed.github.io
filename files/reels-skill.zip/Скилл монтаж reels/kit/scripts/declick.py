"""declick.py IN.wav OUT.wav
Removes wet mouth clicks: finds very short (<=~6ms) high-frequency impulses that stand >14dB above
their neighbourhood and subtracts ONLY the >4kHz component in a ~7ms window around each one.
Voice body (low/mid frequencies) and word endings stay intact."""
import sys, numpy as np, wave
from scipy.signal import butter, sosfiltfilt
inp, outp = sys.argv[1], sys.argv[2]
w = wave.open(inp); sr = w.getframerate(); ch = w.getnchannels()
raw = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float).reshape(-1, ch) / 32768
mono = raw.mean(1)
sos = butter(6, 4000, 'hp', fs=sr, output='sos')
hop = int(0.002 * sr)
hm = sosfiltfilt(sos, mono); n = len(hm) // hop
eh = 20 * np.log10(np.sqrt((hm[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9)
spikes = []
for i in range(10, n - 10):
    nb = np.r_[eh[i - 8:i - 2], eh[i + 3:i + 9]]
    if eh[i] - np.median(nb) > 14 and eh[i] == eh[i - 2:i + 3].max() and eh[i] > -50:
        spikes.append(i)
g = np.ones(len(mono))
pre, post, fade = int(0.003 * sr), int(0.004 * sr), int(0.0015 * sr)
for i in spikes:
    c = i * hop + hop // 2
    s0, s1 = max(0, c - pre), min(len(g), c + post)
    win = np.full(s1 - s0, 0.08)
    win[:fade] = np.linspace(1, 0.08, fade); win[-fade:] = np.linspace(0.08, 1, fade)
    g[s0:s1] = np.minimum(g[s0:s1], win)
out = np.empty_like(raw)
for k in range(ch):
    hk = sosfiltfilt(sos, raw[:, k])
    out[:, k] = raw[:, k] - hk * (1 - g)
o = wave.open(outp, 'wb'); o.setnchannels(ch); o.setsampwidth(2); o.setframerate(sr)
o.writeframes((out * 32768).clip(-32768, 32767).astype(np.int16).tobytes()); o.close()
print('clicks removed:', len(spikes))
