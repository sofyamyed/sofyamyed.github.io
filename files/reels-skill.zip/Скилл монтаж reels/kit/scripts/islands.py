"""islands.py SRC WORKDIR -> WORKDIR/audio.wav (16 kHz mono) + islands.json (speech chunks, one per take)."""
import sys, os, json, subprocess, numpy as np, wave
src, wd = sys.argv[1], sys.argv[2]
os.makedirs(wd, exist_ok=True)
wav = os.path.join(wd, 'audio.wav')
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', src, '-vn', '-ac', '1', '-ar', '16000', wav], check=True)
w = wave.open(wav); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
win = 1600  # 0.1 s
db = 20 * np.log10(np.sqrt(np.mean(a[:len(a) // win * win].reshape(-1, win) ** 2, axis=1)) + 1e-9)
# threshold: between noise floor and speech level (quiet gated mics sit near -80 dB)
thr = max(-62, min(-40, (np.percentile(db, 20) + np.percentile(db, 90)) / 2))
sp = db > thr; segs = []; s = None
for i, v in enumerate(sp):
    if v and s is None: s = i
    if not v and s is not None: segs.append([s, i]); s = None
if s is not None: segs.append([s, len(sp)])
m = []
for x in segs:
    if m and x[0] - m[-1][1] <= 3: m[-1][1] = x[1]
    else: m.append(x)
m = [(a_ / 10, b_ / 10) for a_, b_ in m if b_ - a_ >= 2]
json.dump(m, open(os.path.join(wd, 'islands.json'), 'w'))
print('threshold', round(thr), 'dB; islands:', len(m))
