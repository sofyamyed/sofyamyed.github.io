"""make_base.py SRC WORKDIR 'a-b,a-b,...'
Cuts chosen takes (with inner pauses >0.35s removed), speeds x1.3, color, loudnorm -> base.mp4,
and maps word timings from isl_words.json to the output timeline -> words_out.json."""
import sys, json, subprocess, os
import numpy as np, wave

src, wd, takes_s = os.path.abspath(sys.argv[1]), sys.argv[2], sys.argv[3]
takes = [tuple(map(float, t.split('-'))) for t in takes_s.split(',')]
os.chdir(wd)
w = wave.open('audio.wav'); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float) / 32768
hop, win = 160, 400
n = (len(a) - win) // hop
db = np.array([20 * np.log10(np.sqrt(np.mean(a[i * hop:i * hop + win] ** 2)) + 1e-9) for i in range(n)])
keep = []
for A, B in takes:
    i0, i1 = int(A * 100), int(B * 100)
    sp = db[i0:i1] > -60
    runs = []; s = None
    for k, v in enumerate(sp):
        if v and s is None: s = k
        if not v and s is not None: runs.append([s, k]); s = None
    if s is not None: runs.append([s, len(sp)])
    m = []
    for r in runs:
        if m and r[0] - m[-1][1] < 35: m[-1][1] = r[1]
        else: m.append(r)
    m = [r for r in m if r[1] - r[0] >= 6]
    for k_, r in enumerate(m):
        end = A + r[1] / 100 + 0.08
        if k_ == len(m) - 1:
            # take end: extend until real silence (catches quiet final plosives like -к, -т), max +0.4s
            j = int(end * 100); lim = j + 40
            while j < lim and j + 5 < len(db) and db[j:j + 5].max() > -72: j += 1
            end = max(end, j / 100 + 0.04)
        keep.append([round(A + r[0] / 100 - 0.08, 3), round(end, 3)])
k2 = []
for r in keep:
    if k2 and r[0] <= k2[-1][1]: k2[-1][1] = max(k2[-1][1], r[1])
    else: k2.append(r)
keep = k2
json.dump(keep, open('keep.json', 'w'))
print('keep', keep, 'raw sum', round(sum(b - a for a, b in keep), 2))

# iPhone shoots HDR (HLG / Dolby Vision) by default: without tone mapping the reel looks washed-out and grey
trc = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=color_transfer', '-of', 'csv=p=0', src], text=True).strip()
TONE = ''
if trc in ('arib-std-b67', 'smpte2084'):
    if ' zscale ' in subprocess.run(['ffmpeg', '-hide_banner', '-filters'], capture_output=True, text=True).stdout:
        TONE = 'zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,'
        print('HDR source (' + trc + '): tone mapping to SDR')
    else:
        print('WARNING: HDR source, but this ffmpeg has no zscale filter - colours will look washed-out. Install ffmpeg with zimg (e.g. brew install ffmpeg).')
lst = open('list.txt', 'w')
durs = []
for i, (s0, s1) in enumerate(keep):
    subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-ss', str(s0), '-to', str(s1), '-i', src, '-map', '0:v:0', '-map', '0:a:0',
                    '-vf', TONE + 'fps=30,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,format=yuv420p', '-af', 'afade=t=in:d=0.02', '-c:v', 'libx264', '-crf', '14', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
                    '-preset', 'veryfast', '-threads', '2', '-c:a', 'pcm_s16le', f'seg_{i}.mov'], check=True)
    lst.write(f"file 'seg_{i}.mov'\n")
    durs.append(float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f'seg_{i}.mov'])))
lst.close()
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'joined.mov'], check=True)
# loudness: exact -14 LUFS. Gain + soft peak limiter at -1.5 dB, gain refined by measuring the limited result
# (one-pass loudnorm undershoots by 2-4 dB; linear loudnorm is blocked by single peaks)
def lufs(chain):
    r = subprocess.run(['ffmpeg', '-nostdin', '-hide_banner', '-y', '-i', 'joined.mov', '-vn', '-af', f'atempo=1.3,{chain}loudnorm=print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True, check=True).stderr
    return float(json.loads(r[r.rindex('{'):r.rindex('}') + 1])['input_i'])
gain = -14 - lufs('')
for _ in range(3):
    LN = f'aresample=48000,volume={gain:.2f}dB,alimiter=limit=0.84:attack=2:release=60:level=false'
    err = -14 - lufs(LN + ',')
    if abs(err) < 0.3: break
    gain += err
print('loudness gain', round(gain, 1), 'dB')
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-i', 'joined.mov', '-filter_complex',
                "[0:v]setpts=PTS/1.3,fps=30,eq=brightness=-0.02:contrast=1.03,colorbalance=rm=0.015:bm=-0.015,curves=all='0/0 0.25/0.235 1/1',unsharp=5:5:0.2,format=yuv420p[vo];"
                f"[0:a]atempo=1.3,{LN},aresample=48000[ao]",
                '-map', '[vo]', '-map', '[ao]', '-c:v', 'libx264', '-crf', '18', '-preset', 'medium', '-threads', '2', '-c:a', 'aac', '-b:a', '192k', 'base.mp4'], check=True)
dur = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', 'base.mp4']))
offs = []; o = 0
for d in durs: offs.append(o); o += d

def mp(t):
    for i, (s0, s1) in enumerate(keep):
        if s0 - 0.3 <= t <= s1 + 0.3:
            return round((offs[i] + min(max(t - s0, 0), durs[i])) / 1.3, 3)
    return None

isl = json.load(open('isl_words.json'))
out = []
for it in isl:
    if any(k in it['text'] for k in ('Игорь Негода', 'Субтитры', 'Спасибо.', 'Смешно')): continue
    for wd_ in it['words']:
        if any(A <= wd_['t'] <= B for A, B in takes):
            out.append({'text': wd_['text'], 't': mp(wd_['t']), 'end': mp(wd_['end'])})
json.dump(out, open('words_out.json', 'w'), ensure_ascii=False)
json.dump({'duration': dur}, open('meta.json', 'w'))
print('duration', dur)
for i, x in enumerate(out):
    print(i, x['t'], x['text'])
for f in os.listdir('.'):
    if f.startswith('seg_') or f == 'joined.mov':
        os.remove(f)
