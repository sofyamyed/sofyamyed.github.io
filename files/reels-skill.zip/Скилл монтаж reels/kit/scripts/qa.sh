#!/bin/bash
# qa.sh PROPS.json OUTDIR frame1 frame2 ...  -> OUTDIR/qa_sheet.jpg (4 per row) via Remotion stills
# Stops with the Remotion error text if any frame fails to render.
set -e
P=$(cd "$(dirname "$1")" && pwd)/$(basename "$1"); O=$2; shift 2; mkdir -p "$O"; O=$(cd "$O" && pwd)
cd "$(dirname "$0")/../remotion"
for f in "$@"; do
  rm -f "$O/q$f.png"
  if ! npx remotion still src/index.ts Reel "$O/q$f.png" --frame=$f --props="$P" --log=error > "$O/still.log" 2>&1 || [ ! -s "$O/q$f.png" ]; then
    echo "ОШИБКА: кадр $f не отрисовался:"; tail -20 "$O/still.log"; exit 1
  fi
done
python3 - "$O" "$@" <<'PY'
import sys; from PIL import Image
o, fr = sys.argv[1], sys.argv[2:]
ims = [Image.open(f'{o}/q{f}.png').convert('RGB').resize((360, 640)) for f in fr]
cols = 4; rows = (len(ims) + cols - 1) // cols
sheet = Image.new('RGB', (360 * cols, 640 * rows), 'black')
for i, im in enumerate(ims): sheet.paste(im, ((i % cols) * 360, (i // cols) * 640))
sheet.save(f'{o}/qa_sheet.jpg', quality=88)
PY
echo "$O/qa_sheet.jpg"
