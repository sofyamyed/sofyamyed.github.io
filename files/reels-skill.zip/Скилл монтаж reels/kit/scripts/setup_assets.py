"""setup_assets.py [WORKFOLDER]
Puts Montserrat-ExtraBold.ttf, Montserrat-Medium.ttf and gradient-niz.png into kit/remotion/public/.
1) takes them from WORKFOLDER (fonts/, assets/, root, any subfolder) if the user put them there;
2) otherwise downloads Montserrat from npm (@expo-google-fonts/montserrat, OFL; identical to Google Fonts)
   and draws the gradient (black, alpha rising linearly to the bottom - same as the original Figma file)."""
import sys, os, shutil, subprocess, tempfile, glob, tarfile
import numpy as np
from PIL import Image

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PUB = os.path.join(KIT, 'remotion', 'public')
FON = os.path.join(PUB, 'fonts')
os.makedirs(FON, exist_ok=True)
work = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(KIT)
need = {'Montserrat-ExtraBold.ttf': os.path.join(FON, 'Montserrat-ExtraBold.ttf'),
        'Montserrat-Medium.ttf': os.path.join(FON, 'Montserrat-Medium.ttf'),
        'gradient-niz.png': os.path.join(PUB, 'gradient-niz.png')}


def find(name):
    for p in glob.glob(os.path.join(work, '**', name), recursive=True):
        if os.path.abspath(p) != need[name] and 'node_modules' not in p:
            return p


for name, dst in need.items():
    if os.path.exists(dst):
        print('ok   ', name); continue
    src = find(name)
    if src:
        shutil.copy(src, dst); print('copy ', name, '<-', src)

missing_fonts = [n for n in ('Montserrat-ExtraBold.ttf', 'Montserrat-Medium.ttf') if not os.path.exists(need[n])]
if missing_fonts:
    tmp = tempfile.mkdtemp()
    subprocess.run('npm pack @expo-google-fonts/montserrat@0.4.1', shell=True, cwd=tmp, check=True, capture_output=True)
    with tarfile.open(glob.glob(os.path.join(tmp, '*.tgz'))[0]) as t:
        t.extractall(tmp, filter='data') if hasattr(tarfile, 'data_filter') else t.extractall(tmp)
    src = {'Montserrat-ExtraBold.ttf': '800ExtraBold/Montserrat_800ExtraBold.ttf', 'Montserrat-Medium.ttf': '500Medium/Montserrat_500Medium.ttf'}
    for n in missing_fonts:
        shutil.copy(os.path.join(tmp, 'package', src[n]), need[n]); print('npm  ', n)
    shutil.rmtree(tmp, ignore_errors=True)

if not os.path.exists(need['gradient-niz.png']):
    W, H = 2160, 2036                       # shown at width 1080 -> bottom 1018 px of the frame
    y = np.arange(H, dtype=float)
    alpha = np.clip(0.06241 * y - 30.116, 0, 255).round().astype(np.uint8)
    img = np.zeros((H, W, 4), np.uint8); img[:, :, 3] = alpha[:, None]
    Image.fromarray(img, 'RGBA').save(need['gradient-niz.png']); print('drew  gradient-niz.png')

print('assets ready in', PUB)
