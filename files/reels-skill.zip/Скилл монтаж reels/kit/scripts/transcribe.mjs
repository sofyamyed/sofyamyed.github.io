// node transcribe.mjs WORKDIR  -> WORKDIR/isl_words.json (every take transcribed separately, word timings)
// Model: Xenova/whisper-small via transformers.js. Downloads from Hugging Face; if that is blocked,
// install the npm mirror once:  npm pack sts-whisper-small && tar xzf sts-whisper-small-*.tgz  (in this scripts folder)
import { pipeline, env } from '@huggingface/transformers';
import fs from 'fs'; import path from 'path'; import wf from 'wavefile'; import { fileURLToPath } from 'url';
const wd = process.argv[2];
const here = path.dirname(fileURLToPath(import.meta.url));  // works with spaces/Cyrillic in the path and on Windows
const local = path.join(here, 'package', 'models');
if (fs.existsSync(path.join(local, 'Xenova', 'whisper-small'))) { env.localModelPath = local + '/'; env.allowRemoteModels = false; }
const w = new wf.WaveFile(fs.readFileSync(path.join(wd, 'audio.wav'))); w.toBitDepth('32f');
let s = w.getSamples(); if (Array.isArray(s)) s = s[0];
const audio = Float32Array.from(s);
const asr = await pipeline('automatic-speech-recognition', 'Xenova/whisper-small', {dtype: {encoder_model: 'q8', decoder_model_merged: 'q8'}});
const res = [];
for (const [a, b] of JSON.parse(fs.readFileSync(path.join(wd, 'islands.json')))) {
  const pa = Math.max(0, a - 0.15), pb = b + 0.15;
  const seg = audio.slice(Math.floor(pa * 16000), Math.floor(pb * 16000));
  const r = await asr(seg, {language: 'russian', task: 'transcribe', chunk_length_s: 30, stride_length_s: 5, return_timestamps: 'word'});
  const words = (r.chunks || []).map(c => ({text: c.text.trim(), t: +(pa + c.timestamp[0]).toFixed(3), end: +(pa + (c.timestamp[1] ?? c.timestamp[0])).toFixed(3)}));
  res.push({a, b, text: r.text.trim(), words});
  console.log(`[${a}-${b}] ${r.text.trim()}`);
}
fs.writeFileSync(path.join(wd, 'isl_words.json'), JSON.stringify(res, null, 1));
